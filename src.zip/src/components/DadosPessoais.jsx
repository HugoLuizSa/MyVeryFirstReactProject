import { Button, FormControlLabel, Switch, TextField } from "@mui/material";
import { useContext, useState } from "react";
import ValidacoesCadastro from "../context/ValidacoesCadastro";

export default function DadosPessoais({
  proximo,
  finalizarCadastro,
  validacoes,
}) {
  const [nome, setNome] = useState("");
  const [sobrenome, setSobrenome] = useState("");
  const [cpf, setCpf] = useState("");
  const [promocoes, setPromocoes] = useState(true);
  const [novidades, setNovidades] = useState(true);
  const [erros, setErros] = useState({});

  const validaCampo = useContext(ValidacoesCadastro);

  const getForm = (e) => {
    e.preventDefault();
    console.log({ nome, sobrenome, cpf, promocoes, novidades });
  };

  const validarCampos = (e) => {
    const { name, value } = e.target;

    let ehValido = validaCampo[name](value);

    let novoEstadoErros = { ...erros };
    novoEstadoErros[name] = ehValido;

    setErros(novoEstadoErros);

    validaCampo.printarDados("ASD");
  };

  const setState = (e, setter) => {
    let { value } = e.target;
    setter(value);
  };

  return (
    <form onSubmit={getForm}>
      <TextField
        value={nome}
        onChange={(e) => setState(e, setNome)}
        label="nome"
        variant="outlined"
        fullWidth
        margin="normal"
      />

      <TextField
        value={sobrenome}
        onChange={(e) => setState(e, setSobrenome)}
        label="SobreNome"
        variant="outlined"
        fullWidth
        margin="normal"
      />

      <TextField
        error={erros.cpf?.erro}
        helperText={erros.cpf?.texto}
        onBlur={validarCampos}
        name="cpf"
        value={cpf}
        onChange={(e) => setState(e, setCpf)}
        label="cpf"
        variant="outlined"
        fullWidth
        margin="normal"
      />

      <FormControlLabel
        checked={novidades}
        onChange={(e) => setState(e, setPromocoes)}
        label="promocoes"
        control={<Switch name="promocoes" />}
      />

      <FormControlLabel
        checked={novidades}
        onChange={(e) => setState(e, setNovidades)}
        label="novidades"
        control={<Switch name="novidade" />}
      />

      <Button
        variant="contained"
        color="primary"
        type="submit"
        onClick={() => proximo({ nome, sobrenome, cpf, novidades, promocoes })}
      >
        Cadastrar
      </Button>
    </form>
  );
}
