import { Container, StepLabel, Stepper, Typography, Step } from "@mui/material";
import { useEffect, useState } from "react";
import DadosEntrega from "./DadosEntrega";
import DadosPessoais from "./DadosPessoais";
import DadosUsuario from "./DadosUsuario";

export default function Formulario({ validacoes }) {
  const [etapaInicial, setEtapaAtual] = useState(0);

  const [dadosColetados, setColetarDados] = useState({});

  const coletarDados = (dados) => {
    setColetarDados({ ...dadosColetados, ...dados });
    proximo();
  };

  const proximo = () => {
    let proximaEtapa = etapaInicial + 1;
    setEtapaAtual(proximaEtapa);
  };

  const setState = (e, setter) => {
    let value = e.target.value;
    setter(value);
  };

  useEffect(() => {
    if (etapaInicial === etapasForm.length) {
      console.log(dadosColetados);
    }
  });

  const etapasForm = [
    <DadosUsuario
      setState={setState}
      proximo={coletarDados}
      validacoes={validacoes}
    />,
    <DadosEntrega
      setState={setState}
      proximo={coletarDados}
      validacoes={validacoes}
    />,
    <DadosPessoais
      setState={setState}
      proximo={coletarDados}
      validacoes={validacoes}
    />,
    <Typography align="center" variant="h4">
      Cadastrado com sucesso!
    </Typography>,
  ];

  return (
    <>
      <Stepper activeStep={etapaInicial} margin="normal">
        <Step>
          <StepLabel>Login</StepLabel>
        </Step>
        <Step>
          <StepLabel>Pessoal</StepLabel>
        </Step>
        <Step>
          <StepLabel>Entrega</StepLabel>
        </Step>
        <Step>
          <StepLabel>Finalizacao</StepLabel>
        </Step>
      </Stepper>
      <Container maxWidth="md">{etapasForm[etapaInicial]}</Container>
    </>
  );
}
