import { TextField, Typography, Button } from "@mui/material";
import React, { useContext, useState } from "react";
import ValidacoesCadastro from "../context/ValidacoesCadastro";
import useErros from "../hooks/useErros";

export default function DadosUsuario({ proximo, setState, validacoes }) {
  const validaCampo = useContext(ValidacoesCadastro);

  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const [erros, validarCampo] = useErros(validaCampo);

  /*  const validarCampo = ({ target: { name, value } }) => {
    const validar = validaCampo[name];
    let ehValido = validar(value);

    const novoEstadoErro = { ...erros };
    novoEstadoErro[name] = ehValido;

    setErro(novoEstadoErro);
  }; */

  let possoEnviar = () => {
    for (const key in erros) {
      if (erros[key].erros) {
        return false;
      }
    }
    return true;
  };

  const aoEnviar = () => {
    console.log(email, senha, possoEnviar());

    if (possoEnviar()) {
      proximo({ email, senha });
    }
  };

  return (
    <>
      <Typography>Dados Usuario</Typography>
      <form>
        <TextField
          value={email}
          onChange={(e) => setState(e, setEmail)}
          fullWidth
          variant="outlined"
          label="login"
          margin="normal"
          required
        />
        <TextField
          error={erros.senha.erros}
          helperText={erros.senha.texto}
          value={senha}
          onChange={(e) => setState(e, setSenha)}
          fullWidth
          variant="outlined"
          label="senha"
          name="senha"
          margin="normal"
          required
          onBlur={validarCampo}
        />
        <Button variant="contained" onClick={aoEnviar}>
          cadastrar
        </Button>
      </form>
    </>
  );
}
