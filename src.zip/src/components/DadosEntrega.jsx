import React, { useState } from "react";
import TextField from "@mui/material/TextField";
import { Button } from "@mui/material";

export default function DadosEntrega({ proximo, setState }) {
  const [cep, setCep] = useState("");
  const [numero, setNumero] = useState(0);
  const [endereco, setEndereco] = useState("");
  const [estado, setEstado] = useState("");
  const [cidade, setCidade] = useState("");

  const printarDados = () => {
    console.log({ cep, numero, endereco, estado, cidade });
  };

  return (
    <form>
      <TextField
        id="cep"
        label="CEP"
        type="text"
        variant="outlined"
        margin="normal"
        fullWidth
        onChange={(e) => setState(e, setCep)}
      />

      <TextField
        id="numero"
        label="numero"
        type="number"
        variant="outlined"
        margin="normal"
        fullWidth
        onChange={(e) => setState(e, setNumero)}
      />

      <TextField
        id="endereco"
        label="endereco"
        type="text"
        variant="outlined"
        margin="normal"
        fullWidth
        onChange={(e) => setState(e, setEndereco)}
      />

      <TextField
        id="cep"
        label="estado"
        type="text"
        variant="outlined"
        margin="normal"
        fullWidth
        onChange={(e) => setState(e, setEstado)}
      />

      <TextField
        id="cidade"
        label="cidade"
        type="text"
        variant="outlined"
        margin="normal"
        fullWidth
        onChange={(e) => setState(e, setCidade)}
      />

      <Button
        fullWidth
        variant="contained"
        onClick={() => {
          proximo({ cep, numero, endereco, estado, cidade });
          printarDados();
        }}
      >
        Finalizar cadastro
      </Button>
    </form>
  );
}
