function validarCPF(cpf) {
  let novoEstadoErro;

  if (cpf.length !== 11) {
    novoEstadoErro = { erros: true, texto: "CPF deve conter 11 digitos" };
  } else {
    novoEstadoErro = { erros: false, texto: "" };
  }
  return novoEstadoErro;
}

function validarSenha(senha) {
  let novoEstadoErro;

  if (senha.length < 4 || senha.length > 72) {
    novoEstadoErro = {
      erros: true,
      texto: "senha deve conter entre 4 e 72 digitos",
    };
  } else {
    novoEstadoErro = { erros: false, texto: "" };
  }
  return novoEstadoErro;
}

export { validarCPF, validarSenha };
