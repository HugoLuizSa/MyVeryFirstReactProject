import React, { useState } from "react";

const useErros = (validacao) => {
  const estadoInicial = criarNovoEstado(validacao);
  const [erros, setErros] = useState(estadoInicial);

  const validarCampos = ({ target: { name, value } }) => {
    const novoEstadoErro = { ...erros };
    novoEstadoErro[name] = validacao[name](value);
    setErros(novoEstadoErro);
  };

  return [erros, validarCampos];
};

const criarNovoEstado = (validacao) => {
  const estadoInicial = {};

  for (const key in validacao) {
    estadoInicial[key] = { erros: false, texto: "" };
  }

  return estadoInicial;
};

export default useErros;
