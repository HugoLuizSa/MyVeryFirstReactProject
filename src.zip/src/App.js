import "./App.css";
import Formulario from "./components/Fomulario";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";

import { validarCPF, validarSenha } from "./models/cadastro";
import ValidacoesCadastro from "./context/ValidacoesCadastro";

function App() {
  return (
    <Container maxWidth="sm" className="dark">
      <Typography component="h1" variant="h4" color="GrayText" align="center">
        Formulario Cadastro
      </Typography>
      {/*  <ValidacoesCadastro.Provider
        value={{ cpf: validarCPF, senha: validarSenha }}
      > */}
      <Formulario />
      {/*  </ValidacoesCadastro.Provider> */}
    </Container>
  );
}

export default App;
